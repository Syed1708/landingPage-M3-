const testimonialData = [
    {
        title: "Testimonials",
        des: "Here  I will add my all assignments one by one with Vue JS"
    },
    {
        image:'https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(10).webp',
        name: 'Maria Kate',
        designation: 'Photographer',
        description: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus et deleniti
        nesciunt sint eligendi reprehenderit reiciendis, quibusdam illo, beatae quia fugit
        consequatur laudantium velit magnam error. Consectetur distinctio fugit
        doloremque.`
    },
    {
        image:'https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(32).webp',
        name: 'Jane Doe',
        designation: 'Web Developer',
        description: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus et deleniti
        nesciunt sint eligendi reprehenderit reiciendis, quibusdam illo, beatae quia fugit
        consequatur laudantium velit magnam error. Consectetur distinctio fugit
        doloremque.`
    },
    {
        image:'https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(1).webp',
        name: 'Anna Deynah',
        designation: 'UX Designer',
        description: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus et deleniti
        nesciunt sint eligendi reprehenderit reiciendis, quibusdam illo, beatae quia fugit
        consequatur laudantium velit magnam error. Consectetur distinctio fugit
        doloremque.`
    },
    
]

export {testimonialData}