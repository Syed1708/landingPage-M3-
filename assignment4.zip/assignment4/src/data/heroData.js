const heroData = [
    {
        title: "HERO TITLE",
        description: `Lorem ipsum dolor, sit amet consectetur adipisicing elit. Numquam ipsam eaque modi, iste est atque
        voluptates officia? Ipsam, corporis!
        Eius consequuntur nostrum necessitatibus nam assumenda consequatur quas iste rerum autem.`
    },


]




export {heroData}