const assignmentData = [
    {
        title: "Assignments",
        description: "Here I will add my all assignments one by one with Vue JS"
    },

    {
        assTitle: "Create a weather application",
        assDes: `Build a weather application that retrieves and displays the current weather information for a given
        location. The application should utilize HTML, CSS, Bootstrap, and JavaScript`
    },
    {
        assTitle: "Next Assignment",
        assDes: `Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore`
    },
    {
        assTitle: "Create a weather application",
        assDes: `Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia`
    },
    {
        assTitle: "Create a weather application",
        assDes: `At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis`
    },
    {
        assTitle: "Next Assignment",
        assDes: `Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore`
    },
    {
        assTitle: "Create a weather application",
        assDes: `Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia`
    },
    {
        assTitle: "Create a weather application",
        assDes: `At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis`
    },
]




export {assignmentData}

